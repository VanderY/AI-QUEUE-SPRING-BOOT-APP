package com.ai.queue.aiQueue.controller;

public class QueueController {
}
